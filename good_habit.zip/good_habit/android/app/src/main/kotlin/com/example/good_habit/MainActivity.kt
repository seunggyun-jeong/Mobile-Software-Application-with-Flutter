package com.example.good_habit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
